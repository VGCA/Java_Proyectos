import { MoviesGrid } from "./MoviesGrid";

export function App() {
  return (
    <div>
      <header>Películas en taquilla</header>
      <main>
        <MoviesGrid />
      </main>
    </div>
  );
}
