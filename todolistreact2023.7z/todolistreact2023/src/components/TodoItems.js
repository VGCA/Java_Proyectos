import React from 'react'
import './css/TodoItems.css'
import tick from './Assets/tick.png'
import not_tick from './Assets/not_tick.png'
import cross from './Assets/cross.png'

export const TodoItems = ({ number, display, text,setTodos }) => {
  const toggle = (number) => {
    let data = JSON.parse(localStorage.getItem('todos'))
    for(let i=0;i<data.length;i++){
      if(data[i].number===number){
        if(data[i].display===""){
          data[i].display="line-through"
        }else{
          data[i].display=""
        }
        break;
      }
    }
    setTodos(data)
  }

  const deleteTodo=(number)=>{
    let data = JSON.parse(localStorage.getItem('todos'))
    data=data.filter((todo)=>todo.number!==number)
    setTodos(data)
  }

  return (
    <div className='todoitems'>
      <div className={'todoitems-container ${display}'} onClick={() => { toggle(number) }}>
        {display === "" ? <img src={not_tick} alt=''></img>
          : <img src={tick} alt=''></img>}
        <div className='todoitems-text'>{text}</div>
      </div>
      <img className='todoitems-cross-icon' onClick={()=>{deleteTodo(number)}} src={cross} alt=''></img>
    </div>
  )
}
