import React, { useEffect, useRef, useState } from 'react'
import './css/Todo.css'
import { TodoItems } from './TodoItems';

let counter = 0;
const Todo = () => {

  const [todos, setTodos] = useState([]);
  const inputRef = useRef(null);

  function add() {
    setTodos([...todos, {
      number: counter++,
      text: inputRef.current.value,
      display: ""
    }])
    inputRef.current.value = ""
    localStorage.setItem("todos_count",counter)
  }

  useEffect(() => {
    setTodos(JSON.parse(localStorage.getItem("todos")))
    counter=localStorage.getItem("todos_count")
  },[])

  useEffect(() => {
    setTimeout(() => {
      console.log(todos)
      localStorage.setItem("todos", JSON.stringify(todos))
    }, 100)
  }, [todos])

  return (
    <div className='todo'>
      <div className='todo-header'>To-Do List</div>
      <div className='todo-add'>
        <input ref={inputRef} type='text' placeholder='Add your task' className='todo-input'></input>
        <div onClick={() => { add() }} className='todo-add-btn'>ADD</div>
      </div>
      <div className='todo-list'>
        {todos.map((item, index) => {
          return <TodoItems key={index} setTodos={setTodos} number={item.number} display={item.display} text={item.text} />
        })}
      </div>
    </div>
  )
}

export default Todo;
